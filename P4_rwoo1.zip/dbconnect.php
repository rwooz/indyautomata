<?php
//connect to mysql database
$con = mysqli_connect("lamp.cse.fau.edu", "rwoo1", "3Or13GxtOU", "rwoo1") or die("Error " . mysqli_error($con));
?>